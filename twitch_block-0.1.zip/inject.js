var config = {
    attributes: false,
    childList: true,
    characterData: false,
    subtree: true
};

var blockButton = [
    '<a class="button button--icon-only float-left" id="blockEdit" title="Edit Block List">',
    '<figure class="icon">',
    '<svg class="svg-edit-block" height="16" viewBox="0 0 16 16" width="16">',
    '<path d="M8,1C4.13,1,1,4.13,1,8s3.13,7,7,7s7-3.13,7-7S11.87,1,8,1z M3,8c0-2.76,2.24-5,5-5 c1.02,0,1.97,0.31,2.76,0.83l-6.93,6.93C3.31,9.97,3,9.02,3,8z M8,13c-1.02,0-1.97-0.31-2.76-0.83l6.93-6.93 C12.69,6.03,13,6.98,13,8C13,10.76,10.76,13,8,13z"/>',
    '</svg>',
    '</figure>',
    '</a>'
].join('');


var blockList = localStorage.getItem('twitchBlockList') || [];
var loaded;

//MutationObserver for buttons loaded
var buttonsLoaded = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
        var chatSelector = $('.chat-buttons-container');
        if (chatSelector.length > 0) {
            buttonsLoaded.disconnect();
            loaded = true;
        }
    });
    if (loaded) {
        addButton();
    }
});
buttonsLoaded.observe($("body")[0], config);

//Mutation observer for each chat message
var chatObserver = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
        mutation.addedNodes.forEach(function(addedNode) {
            var from = $(addedNode).find('.from')[0];
            if (typeof from == 'object') {
                var twitchID = from.innerHTML;
                isBlocked(twitchID, $(addedNode));
                if ($('#blockEdit').length === 0) {
                    buttonsLoaded.observe($("body")[0], config);
                }
            }
        });
    });
});

//Mutation observer for chat loading
var chatLoaded = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
        var chatSelector = $(".chat-lines");
        if (chatSelector.length > 0) {
            var target = chatSelector[0];
            chatObserver.observe(target, config);
        }
    });
});
chatLoaded.observe($("body")[0], config);




function isBlocked(twitchID, node) {
    if (blockList.indexOf(twitchID) !== -1) {
        console.log(twitchID + ' is blocked.');
        node.remove();
    }
}

function addButton() {
    $('.chat-buttons-container').append(blockButton);
    document.getElementById('blockEdit').addEventListener('click', blockListEdit);
}

function blockListEdit() {
    console.log('edit');
    var tempList = prompt("Edit blocked list (seperate users by comma - case sensitive): ", blockList);
    blockList = tempList.split(',');
    localStorage.setItem('twitchBlockList', blockList);
    console.log(blockList);
}
